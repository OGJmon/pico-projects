Keypad

C Grade:  Get the keypad to work and print

B Grade:  C Grage & Be able to enter a number; print the number

A Grade:  B Grade & Enter a number with backspace

